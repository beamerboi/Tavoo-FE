import {
  ActiveDescendantKeyManager,
  AriaDescriber,
  CDK_DESCRIBEDBY_HOST_ATTRIBUTE,
  CDK_DESCRIBEDBY_ID_PREFIX,
  ConfigurableFocusTrap,
  ConfigurableFocusTrapFactory,
  EventListenerFocusTrapInertStrategy,
  FOCUS_TRAP_INERT_STRATEGY,
  MESSAGES_CONTAINER_ID,
  NOOP_TREE_KEY_MANAGER_FACTORY_PROVIDER,
  NoopTreeKeyManager,
  TREE_KEY_MANAGER,
  TreeKeyManager,
  addAriaReferencedId,
  getAriaReferenceIds,
  removeAriaReferencedId
} from "./chunk-OP2W4UQV.js";
import {
  FocusKeyManager,
  ListKeyManager
} from "./chunk-A7GVAXXK.js";
import {
  A11yModule,
  CdkAriaLive,
  CdkTrapFocus,
  FocusTrap,
  FocusTrapFactory,
  HighContrastMode,
  HighContrastModeDetector,
  InteractivityChecker,
  IsFocusableConfig,
  LIVE_ANNOUNCER_DEFAULT_OPTIONS,
  LIVE_ANNOUNCER_ELEMENT_TOKEN,
  LiveAnnouncer
} from "./chunk-PJAK7775.js";
import "./chunk-DU2TPKI3.js";
import {
  CdkMonitorFocus,
  FOCUS_MONITOR_DEFAULT_OPTIONS,
  FocusMonitor,
  FocusMonitorDetectionMode,
  INPUT_MODALITY_DETECTOR_DEFAULT_OPTIONS,
  INPUT_MODALITY_DETECTOR_OPTIONS,
  InputModalityDetector
} from "./chunk-2KJKHA74.js";
import {
  isFakeMousedownFromScreenReader,
  isFakeTouchstartFromScreenReader
} from "./chunk-FJLHLNUT.js";
import "./chunk-62WZ6XJB.js";
import {
  _IdGenerator
} from "./chunk-SKJ5UOOR.js";
import "./chunk-IUA6AL5Z.js";
import "./chunk-56YIOAIA.js";
import "./chunk-OBF5IYM7.js";
import "./chunk-YMG7VQF7.js";
import "./chunk-4PEN7LSJ.js";
import "./chunk-RSS3ODKE.js";
import "./chunk-RW4ES5HA.js";
export {
  A11yModule,
  ActiveDescendantKeyManager,
  AriaDescriber,
  CDK_DESCRIBEDBY_HOST_ATTRIBUTE,
  CDK_DESCRIBEDBY_ID_PREFIX,
  CdkAriaLive,
  CdkMonitorFocus,
  CdkTrapFocus,
  ConfigurableFocusTrap,
  ConfigurableFocusTrapFactory,
  EventListenerFocusTrapInertStrategy,
  FOCUS_MONITOR_DEFAULT_OPTIONS,
  FOCUS_TRAP_INERT_STRATEGY,
  FocusKeyManager,
  FocusMonitor,
  FocusMonitorDetectionMode,
  FocusTrap,
  FocusTrapFactory,
  HighContrastMode,
  HighContrastModeDetector,
  INPUT_MODALITY_DETECTOR_DEFAULT_OPTIONS,
  INPUT_MODALITY_DETECTOR_OPTIONS,
  InputModalityDetector,
  InteractivityChecker,
  IsFocusableConfig,
  LIVE_ANNOUNCER_DEFAULT_OPTIONS,
  LIVE_ANNOUNCER_ELEMENT_TOKEN,
  ListKeyManager,
  LiveAnnouncer,
  MESSAGES_CONTAINER_ID,
  NOOP_TREE_KEY_MANAGER_FACTORY_PROVIDER,
  NoopTreeKeyManager,
  TREE_KEY_MANAGER,
  TreeKeyManager,
  _IdGenerator,
  addAriaReferencedId,
  getAriaReferenceIds,
  isFakeMousedownFromScreenReader,
  isFakeTouchstartFromScreenReader,
  removeAriaReferencedId
};
