import {
  FullscreenOverlayContainer
} from "./chunk-3L65ID2R.js";
import {
  BlockScrollStrategy,
  CDK_CONNECTED_OVERLAY_DEFAULT_CONFIG,
  CdkConnectedOverlay,
  CdkOverlayOrigin,
  CloseScrollStrategy,
  ConnectedOverlayPositionChange,
  ConnectionPositionPair,
  FlexibleConnectedPositionStrategy,
  GlobalPositionStrategy,
  NoopScrollStrategy,
  OVERLAY_DEFAULT_CONFIG,
  Overlay,
  OverlayConfig,
  OverlayContainer,
  OverlayKeyboardDispatcher,
  OverlayModule,
  OverlayOutsideClickDispatcher,
  OverlayPositionBuilder,
  OverlayRef,
  RepositionScrollStrategy,
  STANDARD_DROPDOWN_ADJACENT_POSITIONS,
  STANDARD_DROPDOWN_BELOW_POSITIONS,
  ScrollStrategyOptions,
  ScrollingVisibility,
  createBlockScrollStrategy,
  createCloseScrollStrategy,
  createFlexibleConnectedPositionStrategy,
  createGlobalPositionStrategy,
  createNoopScrollStrategy,
  createOverlayRef,
  createRepositionScrollStrategy,
  validateHorizontalPosition,
  validateVerticalPosition
} from "./chunk-OBX43VS3.js";
import "./chunk-VON75VBJ.js";
import {
  CdkFixedSizeVirtualScroll,
  CdkScrollable,
  CdkScrollableModule,
  CdkVirtualForOf,
  CdkVirtualScrollViewport,
  CdkVirtualScrollableElement,
  CdkVirtualScrollableWindow,
  Dir,
  ScrollDispatcher,
  ViewportRuler
} from "./chunk-U6WFQN57.js";
import "./chunk-62WZ6XJB.js";
import "./chunk-SKJ5UOOR.js";
import "./chunk-IUA6AL5Z.js";
import "./chunk-56YIOAIA.js";
import "./chunk-OBF5IYM7.js";
import "./chunk-YMG7VQF7.js";
import "./chunk-4PEN7LSJ.js";
import "./chunk-RSS3ODKE.js";
import "./chunk-RW4ES5HA.js";
export {
  BlockScrollStrategy,
  CDK_CONNECTED_OVERLAY_DEFAULT_CONFIG,
  CdkConnectedOverlay,
  CdkOverlayOrigin,
  CdkScrollable,
  CloseScrollStrategy,
  ConnectedOverlayPositionChange,
  ConnectionPositionPair,
  FlexibleConnectedPositionStrategy,
  FullscreenOverlayContainer,
  GlobalPositionStrategy,
  NoopScrollStrategy,
  OVERLAY_DEFAULT_CONFIG,
  Overlay,
  OverlayConfig,
  OverlayContainer,
  OverlayKeyboardDispatcher,
  OverlayModule,
  OverlayOutsideClickDispatcher,
  OverlayPositionBuilder,
  OverlayRef,
  RepositionScrollStrategy,
  STANDARD_DROPDOWN_ADJACENT_POSITIONS,
  STANDARD_DROPDOWN_BELOW_POSITIONS,
  ScrollDispatcher,
  ScrollStrategyOptions,
  ScrollingVisibility,
  ViewportRuler,
  createBlockScrollStrategy,
  createCloseScrollStrategy,
  createFlexibleConnectedPositionStrategy,
  createGlobalPositionStrategy,
  createNoopScrollStrategy,
  createOverlayRef,
  createRepositionScrollStrategy,
  validateHorizontalPosition,
  validateVerticalPosition,
  CdkFixedSizeVirtualScroll as ɵɵCdkFixedSizeVirtualScroll,
  CdkScrollableModule as ɵɵCdkScrollableModule,
  CdkVirtualForOf as ɵɵCdkVirtualForOf,
  CdkVirtualScrollViewport as ɵɵCdkVirtualScrollViewport,
  CdkVirtualScrollableElement as ɵɵCdkVirtualScrollableElement,
  CdkVirtualScrollableWindow as ɵɵCdkVirtualScrollableWindow,
  Dir as ɵɵDir
};
